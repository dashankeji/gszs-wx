// pages/aboutWeDetails/index.js
const app = getApp()
var WxParse = require('../../wxParse/wxParse.js');

Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
  },

  /**
   * 组件的方法列表
   */
  methods: {
     //  关于我们详情数据请求
     aboutWeDetailsReq: function() {
       var that = this;
       var header = {
         'content-type': 'application/x-www-form-urlencoded',
       };
       wx.request({
         url: app.globalData.url + '/api/about',
         method: 'GET',
         header: header,
         success: function (res) {
           WxParse.wxParse('content', 'html', res.data.data[0].content, that, 0);
         },
         fail: function (res) {
           wx.showToast({
             title: "获取关于我们详情数据失败",
             icon: 'none',
             duration: 2000
           });
         }
       });
     },
     //  页面初始化加载
     onLoad: function() {
         var that = this;
             that.aboutWeDetailsReq();
    },
    //  用户点击右上角分享
    onShareAppMessage: function () {
    }
  }
})
