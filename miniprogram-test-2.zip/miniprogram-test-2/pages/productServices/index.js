// pages/productServices/index.js
const app = getApp()

Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    UrlReqPrefix: app.globalData.url,   //数据请求前缀
    ImgUrlReqPrefix: app.globalData.imgUrl, // 图片请求前缀 
    //  产品服务
    productTopImgUrl: '',    //产品服务顶部图片数据
    productDatas: [],   //产品服务数据
  },

  /**
   * 组件的方法列表
   */
  methods: {
    //  产品服务顶部图片数据请求
    productTopImgUrlReq: function() {
      var that = this;
      var header = {
        'content-type': 'application/x-www-form-urlencoded',
      };
      wx.request({
        url: app.globalData.url + '/api/getTopbanner',
        method: 'GET',
        header: header,
        success: function (res) {
          that.setData({
            productTopImgUrl: res.data.data.img
          });
        },
        fail: function (res) {
          wx.showToast({
            title: "获取产品服务顶部图片数据失败",
            icon: 'none',
            duration: 2000
          });
        }
      });
    },
    //  产品服务数据请求
    productDatasReq: function() {
      var that = this;
      var header = {
        'content-type': 'application/x-www-form-urlencoded',
      };
      wx.request({
        url: app.globalData.url + '/api/getProduct',
        method: 'GET',
        data: { ischan: '1' },
        header: header,
        success: function (res) {
          that.setData({
            productDatas: res.data.data.items
          });
        },
        fail: function (res) {
          wx.showToast({
            title: "获取产品服务数据失败",
            icon: 'none',
            duration: 2000
          });
        }
      });
    },
    //  页面初始化加载
    onLoad: function () {
      var that = this;
          that.productDatasReq();
          that.productTopImgUrlReq();
    },
    //  用户点击右上角分享
    onShareAppMessage: function () {
    }
  },

})
