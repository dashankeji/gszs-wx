// pages/aboutWe/index.js
const app = getApp()

Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    UrlReqPrefix: app.globalData.url,   //数据请求前缀
    ImgUrlReqPrefix: app.globalData.imgUrl, // 图片请求前缀 
    //  地图
    markers: [{
      latitude: 21.244933,
      longitude: 110.396205,
      width: 30,
      height: 30,
      callout:{
        content: '湛江南鲸大学生创业公社',
        display: "ALWAYS",
        padding: 10,
        fontSize: 14
      }
    }],
    //  联系我们
    contactWeData: [{}],  // 联系我们数据
    contactWeTopImgUrl: '', // 联系我们顶部图片数据
  },
  /**
   * 组件的方法列表
   */
  methods: {
    //  号码拨打
    tell: function (e) {

      wx.makePhoneCall({
        phoneNumber: e.currentTarget.dataset.phone,
      })

    },
    //  地图
    regionchange(e) {
      console.log(e.type)
    },
    markertap(e) {
      console.log(e.markerId)
    },
    controltap(e) {
      console.log(e.controlId)
    },
    //  二维码点击事件
    sweepCodeClick: function(e) {
     wx.previewImage({
        current: e.currentTarget.dataset.src, // 当前显示图片的http链接
        urls: [e.currentTarget.dataset.src] 
      });
    },
    //  联系我们数据请求
    contactWeDataReq: function() {
      var that = this;
      var header = {
        'content-type': 'application/x-www-form-urlencoded',
      };
      wx.request({
        url: app.globalData.url + '/api/getsys',
        method: 'GET',
        header: header,
        success: function (res) {
          that.setData({
            contactWeData: res.data.data
          });
        },
        fail: function (res) {
          wx.showToast({
            title: "获取联系我们数据失败",
            icon: 'none',
            duration: 2000
          });
        }
      });
    },
    //  联系我们顶部图片数据请求
    contactWeTopImgUrlReq: function() {
      var that = this;
      var header = {
        'content-type': 'application/x-www-form-urlencoded',
      };
      wx.request({
        url: app.globalData.url + '/api/contact',
        method: 'GET',
        header: header,
        success: function (res) {
          that.setData({
            contactWeTopImgUrl: res.data.data.img
          });
        },
        fail: function (res) {
          wx.showToast({
            title: "获取联系我们顶部图片数据失败",
            icon: 'none',
            duration: 2000
          });
        }
      });
    },
    //  页面初始化加载时
    onLoad: function() {
      var that = this;
          that.contactWeDataReq();
          that.contactWeTopImgUrlReq();
    },
    //  用户点击右上角分享
    onShareAppMessage: function () {
    }
  }
})
