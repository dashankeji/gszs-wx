// pages/productServicesDetails/index.js
const app = getApp();
var WxParse = require('../../wxParse/wxParse.js');

Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    CustomBar: app.globalData.CustomBar,
    StatusBar: app.globalData.StatusBar,
    //  产品服务详情title
    backNavTitle: '',
  },

  /**
   * 组件的方法列表
   */
  methods: {
     productServicesDetailsReq: function(id) {
       var that = this;
       var header = {
         'content-type': 'application/x-www-form-urlencoded',
       };
       wx.request({
         url: app.globalData.url + '/api/getProContet',
         method: 'GET',
         data: { id: id },
         header: header,
         success: function (res) {
           that.setData({
             backNavTitle: res.data.data.name
           });
           WxParse.wxParse('content', 'html', res.data.data.content, that, 0);
         },
         fail: function (res) {
           wx.showToast({
             title: "获取产品服务详情数据失败",
             icon: 'none',
             duration: 2000
           });
         }
       });
     },
     //页面初始化加载时
     onLoad: function(options) {
        var that = this;
            if(!options.id) options.id = 0;
            that.productServicesDetailsReq(options.id);
    },
    //  用户点击右上角分享
    onShareAppMessage: function () {
    }
  }
})
