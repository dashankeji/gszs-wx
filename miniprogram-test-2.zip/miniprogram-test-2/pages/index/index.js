//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    UrlReqPrefix: app.globalData.url,   // 数据请求前缀
    ImgUrlReqPrefix: app.globalData.imgUrl, // 图片请求前缀 
    //  轮播
    bannerImgUrls: [],  //轮播图片数据
    currentSwiper: 0,   //轮播焦点
    //  导航
    tabImgUrls: [],  //导航图片数据
    //  关于我们
    aboutWeImgUrls: [],  //关于我们图片数据
    //  产品服务
    productDatas: [],   //产品服务数据
    //  最新动态
    newsDatas: [],   //最新动态数据
    offset: 1,       //最新动态从第几条开始显示数据
    limit: 5,        //最新动态显示多少条数据
  },
  //  轮播数据请求
  bannerImgUrlsReq: function(){
    var that = this;
    var header = {
      'content-type': 'application/x-www-form-urlencoded',
    };
    wx.request({
      url: app.globalData.url + '/api/getBanner',
      method: 'GET',
      header: header,
      success: function (res) {
         that.setData({
            bannerImgUrls: res.data.data.items
         });
      },
      fail: function (res) {
        wx.showToast({
          title: "获取首页轮播图片数据失败",
          icon: 'none',
          duration: 2000
        });
      }
    });
  },
  //  轮播监听
  swiperChange: function (e) {    //轮播监听变化事件
    this.setData({
      currentSwiper: e.detail.current
    })
  },
  //  导航数据请求
  tabImgUrlsReq: function() {
    var that = this;
    var header = {
      'content-type': 'application/x-www-form-urlencoded',
    };
    wx.request({
      url: app.globalData.url + '/api/getTab',
      method: 'GET',
      header: header,
      success: function (res) {
        that.setData({
          tabImgUrls: res.data.data.items
        });
      },
      fail: function (res) {
        wx.showToast({
          title: "获取首页导航数据失败",
          icon: 'none',
          duration: 2000
        });
      }
    });
  },
  //  关于我们数据请求
  aboutWeImgUrls: function() {
    var that = this;
    var header = {
      'content-type': 'application/x-www-form-urlencoded',
    };
    wx.request({
      url: app.globalData.url + '/api/about',
      method: 'GET',
      header: header,
      success: function (res) {
        that.setData({
          aboutWeImgUrls: res.data.data
        });
      },
      fail: function (res) {
        wx.showToast({
          title: "获取首页关于我们数据失败",
          icon: 'none',
          duration: 2000
        });
      }
    });
  },
  //  产品服务数据请求
  productDatasReq:function() {
    var that = this;
    var header = {
      'content-type': 'application/x-www-form-urlencoded',
    };
    wx.request({
      url: app.globalData.url + '/api/getProduct',
      method: 'GET',
      data: {ishome: '1'},
      header: header,
      success: function (res) {
        that.setData({
          productDatas: res.data.data.items
        });
      },
      fail: function (res) {
        wx.showToast({
          title: "获取首页产品服务数据失败",
          icon: 'none',
          duration: 2000
        });
      }
    });
  },
  //  最新动态数据请求
  newsDatasReq: function() {
    var that = this;
    var header = {
      'content-type': 'application/x-www-form-urlencoded',
    };
    wx.request({
      url: app.globalData.url + '/api/getNews',
      method: 'GET',
      data: {pages: that.data.offset, rows: that.data.limit},
      header: header,
      success: function (res) {
        if (res.data.data.items.length) {
          for (var i = 0; i < res.data.data.items.length; i++) {
            var date = new Date(res.data.data.items[i].createtime * 1000),
              Y = date.getFullYear() + '-',
              M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-',
              D = date.getDate() + ' ',
              h = date.getHours() + ':',
              m = date.getMinutes() + ':',
              s = date.getSeconds();
            res.data.data.items[i].createtime = Y + M + D + h + m + s;
          }
        };
        that.setData({
          newsDatas: res.data.data.items
        });
        
      },
      fail: function (res) {
        wx.showToast({
          title: "获取首页最新动态数据失败",
          icon: 'none',
          duration: 2000
        });
      }
    });
  },
  //  页面初始化加载
  onLoad: function(options) {
    var that = this;
        that.bannerImgUrlsReq();
        that.tabImgUrlsReq();
        that.aboutWeImgUrls();
        that.productDatasReq();
        that.newsDatasReq();
  },
  /**
    * 用户点击右上角分享
    */
  onShareAppMessage: function () {
    var that = this;
    return {
      title: '小程序',
      path: '/pages/index/index',
      success: function () {
        wx.showToast({
          title: '分享成功',
          icon: 'success',
          duration: 2000
        })
      }
    }
  },
  //页面到底部后往下拉后发生的事件
  onReachBottom: function () {
    var that = this;
        var offset = ++that.data.offset;
      
    var header = {
      'content-type': 'application/x-www-form-urlencoded',
    };
    wx.request({
      url: app.globalData.url + '/api/getNews',
      method: 'GET',
      data: { page: offset, rows: that.data.limit },
      header: header,
      success: function (res) {
        var len = res.data.data.items.length;
        if (len > 0) {
          for (var i = 0; i < len; i++) {
            var date = new Date(res.data.data.items[i].createtime * 1000),
              Y = date.getFullYear() + '-',
              M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-',
              D = date.getDate() + ' ',
              h = date.getHours() + ':',
              m = date.getMinutes() + ':',
              s = date.getSeconds();
            res.data.data.items[i].createtime = Y + M + D + h + m + s;
          };
          that.data.newsDatas = that.data.newsDatas.concat(res.data.data.items);
          that.setData({
            newsDatas: that.data.newsDatas
          });
          if (len < that.limit){
            wx.showToast({
              title: "数据已经加载到尽头了",
              icon: 'none',
              duration: 2000
            });
            
          };
        }else{
          wx.showToast({
            title: "数据已经加载到尽头了",
            icon: 'none',
            duration: 2000
          });
          that.data.offset--;
        }

      },
      fail: function (res) {
        wx.showToast({
          title: "下拉获取首页最新动态数据失败",
          icon: 'none',
          duration: 2000
        });
        that.offset--;
      }
    });
  },
})
