// pages/newsDetails/index.js
const app = getApp();
var WxParse = require('../../wxParse/wxParse.js');

Page({

  /**
   * 页面的初始数据
   */
  data: {
    CustomBar: app.globalData.CustomBar,
    StatusBar: app.globalData.StatusBar,
    //  最新动态详情title
    backNavTitle: '',
    //  最新动态详情创建时间
    createtime: '',
  },
  //  最新动态详情数据请求
  newsDetailsReq: function(id) {
    var that = this;
    var header = {
      'content-type': 'application/x-www-form-urlencoded',
    };
    wx.request({
      url: app.globalData.url + '/api/getNewscontent',
      method: 'GET',
      data: { id: id },
      header: header,
      success: function (res) {
        var date = new Date(res.data.data.createtime * 1000),
          Y = date.getFullYear() + '-',
          M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-',
          D = date.getDate() + ' ',
          h = date.getHours() + ':',
          m = date.getMinutes() + ':',
          s = date.getSeconds();
          
        that.setData({
          backNavTitle: res.data.data.title,
          createtime: Y + M + D + h + m + s
        });
  
        WxParse.wxParse('content', 'html', res.data.data.content, that, 0);
      },
      fail: function (res) {
        wx.showToast({
          title: "获取最新动态详情数据失败",
          icon: 'none',
          duration: 2000
        });
      }
    });
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    if (!options.id) options.id = 0;
    that.newsDetailsReq(options.id);
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})