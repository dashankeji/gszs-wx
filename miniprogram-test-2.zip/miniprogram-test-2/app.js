//app.js
App({
  onLaunch: function () {
    var that = this;
    wx.getSystemInfo({
      success: e => {
        that.globalData.StatusBar = e.statusBarHeight - 6;
        try {
          let custom = wx.getMenuButtonBoundingClientRect();
          that.globalData.Custom = custom;
          that.globalData.CustomBar = custom.bottom + custom.top - e.statusBarHeight;
        } catch (err) {
          that.globalData.CustomBar = 64;
        }
      }
    });

  },
  globalData: {
    url: 'https://www.largehill.com/dashan/public/index.php',  // 数据请求前缀
    imgUrl: 'https://www.largehill.com/dashan/public'      // 图片请求前缀
  }
})